function stringLength() {
    var name= $("#firstName").val();
    alert("user name is :" + name.length);
}